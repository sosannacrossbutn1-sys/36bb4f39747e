// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("link time report"); }
int main(){
  announce();
  return lionss_run_workload("link-time-report");
}
