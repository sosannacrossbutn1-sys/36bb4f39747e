// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("conformance suite\n", stdout);
  return lionss_run_workload("conformance-suite");
}
