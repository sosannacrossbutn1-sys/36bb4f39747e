// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("crash handler test\n", stdout);
  return lionss_run_workload("crash-handler-test");
}
