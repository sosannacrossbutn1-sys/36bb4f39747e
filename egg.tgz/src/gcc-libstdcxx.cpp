// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("gcc libstdcxx\n", stdout);
  return lionss_run_workload("gcc-libstdcxx");
}
