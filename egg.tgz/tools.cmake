# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(linux-s390x src/linux-s390x.cpp)
set_property(TARGET linux-s390x PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-s390x lionss pthread)

add_executable(tag-validation src/tag-validation.cpp)
set_property(TARGET tag-validation PROPERTY CXX_STANDARD 11)
target_link_libraries(tag-validation lionss pthread)

add_executable(vulnerability-report src/vulnerability-report.cpp)
set_property(TARGET vulnerability-report PROPERTY CXX_STANDARD 11)
target_link_libraries(vulnerability-report lionss pthread)

add_executable(spellcheck src/spellcheck.cpp)
set_property(TARGET spellcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(spellcheck lionss pthread)

add_executable(race-tests src/race-tests.cpp)
set_property(TARGET race-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(race-tests lionss pthread)

add_executable(configure-all-options src/configure-all-options.cpp)
set_property(TARGET configure-all-options PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-all-options lionss pthread)

add_executable(trivy-scan src/trivy-scan.cpp)
set_property(TARGET trivy-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(trivy-scan lionss pthread)

add_executable(man-pages src/man-pages.cpp)
set_property(TARGET man-pages PROPERTY CXX_STANDARD 11)
target_link_libraries(man-pages lionss pthread)

add_executable(linux-aarch64 src/linux-aarch64.cpp)
set_property(TARGET linux-aarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-aarch64 lionss pthread)

add_executable(protocol-fuzz src/protocol-fuzz.cpp)
set_property(TARGET protocol-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(protocol-fuzz lionss pthread)

add_executable(microbench src/microbench.cpp)
set_property(TARGET microbench PROPERTY CXX_STANDARD 11)
target_link_libraries(microbench lionss pthread)

add_executable(oclint src/oclint.cpp)
set_property(TARGET oclint PROPERTY CXX_STANDARD 11)
target_link_libraries(oclint lionss pthread)

add_executable(verify-signatures src/verify-signatures.cpp)
set_property(TARGET verify-signatures PROPERTY CXX_STANDARD 11)
target_link_libraries(verify-signatures lionss pthread)

add_executable(clang-format-check src/clang-format-check.cpp)
set_property(TARGET clang-format-check PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-format-check lionss pthread)

add_executable(signal-handling src/signal-handling.cpp)
set_property(TARGET signal-handling PROPERTY CXX_STANDARD 11)
target_link_libraries(signal-handling lionss pthread)

add_executable(tidy-modernize src/tidy-modernize.cpp)
set_property(TARGET tidy-modernize PROPERTY CXX_STANDARD 11)
target_link_libraries(tidy-modernize lionss pthread)

add_executable(pitest-run src/pitest-run.cpp)
set_property(TARGET pitest-run PROPERTY CXX_STANDARD 11)
target_link_libraries(pitest-run lionss pthread)

add_executable(link-time-report src/link-time-report.cpp)
set_property(TARGET link-time-report PROPERTY CXX_STANDARD 11)
target_link_libraries(link-time-report lionss pthread)

add_executable(conformance-suite src/conformance-suite.cpp)
set_property(TARGET conformance-suite PROPERTY CXX_STANDARD 11)
target_link_libraries(conformance-suite lionss pthread)

add_executable(numa-bench src/numa-bench.cpp)
set_property(TARGET numa-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(numa-bench lionss pthread)

add_executable(grype-scan src/grype-scan.cpp)
set_property(TARGET grype-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(grype-scan lionss pthread)

add_executable(gcc-libstdcxx src/gcc-libstdcxx.cpp)
set_property(TARGET gcc-libstdcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-libstdcxx lionss pthread)

add_executable(asan src/asan.cpp)
set_property(TARGET asan PROPERTY CXX_STANDARD 11)
target_link_libraries(asan lionss pthread)

add_executable(upload-artifacts src/upload-artifacts.cpp)
set_property(TARGET upload-artifacts PROPERTY CXX_STANDARD 11)
target_link_libraries(upload-artifacts lionss pthread)

add_executable(codeblock-run src/codeblock-run.cpp)
set_property(TARGET codeblock-run PROPERTY CXX_STANDARD 11)
target_link_libraries(codeblock-run lionss pthread)

add_executable(out-of-tree-build src/out-of-tree-build.cpp)
set_property(TARGET out-of-tree-build PROPERTY CXX_STANDARD 11)
target_link_libraries(out-of-tree-build lionss pthread)

add_executable(ios-arm64 src/ios-arm64.cpp)
set_property(TARGET ios-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(ios-arm64 lionss pthread)

add_executable(crash-handler-test src/crash-handler-test.cpp)
set_property(TARGET crash-handler-test PROPERTY CXX_STANDARD 11)
target_link_libraries(crash-handler-test lionss pthread)

add_executable(integration-tests src/integration-tests.cpp)
set_property(TARGET integration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(integration-tests lionss pthread)

add_executable(compatibility-tests src/compatibility-tests.cpp)
set_property(TARGET compatibility-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(compatibility-tests lionss pthread)

